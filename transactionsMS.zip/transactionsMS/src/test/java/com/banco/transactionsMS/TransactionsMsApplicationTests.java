package com.banco.transactionsMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionsMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
